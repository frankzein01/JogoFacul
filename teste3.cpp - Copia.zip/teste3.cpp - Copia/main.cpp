#include <math.h>
#include <stdio.h>
#include <allegro.h>

typedef struct{
    int px, py;
    bool ativo;
}PERSONAGEM;

typedef struct{
    int x,y;
    bool ativo;
}INIMIGO;

typedef struct{
    int x,y;
    bool ativo;
}INIMIGO2;

typedef struct{
    int x,y;
    bool ativo;
}INIMIGO3;

typedef struct{
    bool ativo;
}VIDA;

typedef struct{
    bool ativo;
}VIDA1;

typedef struct{
    bool ativo;
}VIDA2;

int menu();
void jogar();
void creditos();

void init();
void deinit();

const int WIDTH = 640;
const int HEIGHT = 480;

int mapa[22][22]={
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},//0
    {0,1,1,1,1,1,1,0,1,1,1,0,1,1,1,1,0,1,1,0,0,0},//1
    {0,1,1,0,1,1,1,0,1,0,1,0,1,0,1,1,1,1,1,1,0,0},//2
    {0,1,0,0,0,1,1,0,1,0,1,1,1,0,0,1,0,1,0,1,1,0},//3
    {0,1,0,0,1,0,1,0,1,1,1,0,1,1,0,1,1,1,0,1,0,0},//4
    {0,1,1,0,1,0,1,1,1,0,1,0,0,1,0,0,0,0,0,1,0,0},//5
    {0,1,0,0,1,0,0,0,0,0,1,0,1,0,0,1,1,1,1,1,0,0},//6
    {0,1,0,0,1,0,1,1,1,1,1,0,1,0,0,1,0,0,0,0,0,0},//7
    {0,1,0,1,1,0,1,0,0,0,1,0,1,0,0,1,1,1,1,1,0,0},//8
    {0,1,1,1,0,0,1,1,1,1,1,1,1,0,0,0,0,0,0,1,0,0},//9
    {0,1,0,0,1,0,1,0,1,0,0,0,1,0,0,1,0,1,1,1,0,0},//10
    {0,1,0,0,1,0,1,0,1,0,0,0,1,0,0,1,0,0,0,1,0,0},//11
    {0,1,1,1,1,0,1,0,1,0,1,1,1,0,0,1,1,1,1,1,0,0},//12
    {0,1,0,0,1,0,1,1,1,0,0,0,1,1,1,0,1,0,0,0,0,0},//13
    {0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,0,1,1,1,1,1,0},//14
    {0,1,0,0,1,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0},//15
    {0,1,0,0,1,1,0,0,1,0,0,1,1,1,1,1,1,1,1,1,0,0},//16
    {0,1,0,0,1,0,0,0,1,0,0,1,0,0,0,0,0,0,0,1,0,0},//17
    {0,1,0,0,1,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,0},//18
    {0,1,1,1,1,0,0,0,0,0,1,0,1,0,0,0,0,0,1,0,0,0},//19
    {0,0,0,0,1,1,1,1,0,0,1,1,1,1,1,1,1,1,1,1,1,1},//20
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}};//21

     bool AtaTempo(int tempo){
        static double tempers;
        static clock_t t0pers= clock(), tfpers;
        tfpers = clock();
        tempers = ((double) (tfpers - t0pers) / (1000/1000));
        if(tempers > tempo){
            tempers = 0;
            t0pers = clock();
            return true;
        }else return false;
    }

int main(){
    init();
    int opcao = 0;
    while(opcao != 3){
        opcao = menu();
        if(opcao == 1){
            jogar();
        }else if(opcao == 2){
            creditos();
        }
    }
    deinit();
    return 0;
}

END_OF_MAIN()

// Menu
int menu(){
    BITMAP *buffer = create_bitmap(640,480);
    BITMAP *botao1ns = load_bitmap("opcao1.bmp", NULL);
    BITMAP *botao1fs = load_bitmap("opcao11.bmp", NULL);
    BITMAP *botao2ns = load_bitmap("opcao2.bmp", NULL);
    BITMAP *botao2fs = load_bitmap("opcao22.bmp", NULL);
    BITMAP *fundo2 = load_bitmap("fundo1.bmp", NULL);

    while(true){
        blit(fundo2, buffer, 0,0,0,0,640,480);
        blit(botao1ns, buffer, 0,0,0,0,460,160);
        blit(botao2ns, buffer, 0,0,0,160,460,160);

        if(mouse_x>0 && mouse_x<340 &&
              mouse_y>0 && mouse_y<160){
                  blit(botao1fs, buffer,0,0,0, 0,340,160);
           }else if(mouse_x>0 && mouse_x<340 &&
              mouse_y>160 && mouse_y<320){
                  blit(botao2fs, buffer,0,0,0, 160,340,160);
           }

           if(mouse_b & 1){
                if(mouse_x>0 && mouse_x<340 &&
                   mouse_y>0 && mouse_y<160){
                         return 1;
                }else if(mouse_x>0 && mouse_x<340 &&
                   mouse_y>160 && mouse_y<320){
                         return 2;
                }
           }

           show_mouse(buffer);
           blit(buffer, screen, 0,0,0,0,640,480);

    }

}

void jogar(){

        PERSONAGEM pers;
        pers.px = 1;
        pers.py = 1;
        pers.ativo = true;

        INIMIGO ini;
        ini.x = 7;
        ini.y = 13;
        ini.ativo = true;

        INIMIGO2 ini2;
        ini2.x = 16;
        ini2.y = 18;
        ini2.ativo = true;

        INIMIGO3 ini3;
        ini3.x = 5;
        ini3.y = 17;
        ini3.ativo = true;

        VIDA life;
        life.ativo = true;
        VIDA1 life1;
        life1.ativo = true;
        VIDA2 life2;
        life2.ativo = true;

        BITMAP *buffer = create_bitmap(WIDTH, HEIGHT);
        BITMAP *fundo = load_bitmap("fundo.bmp", NULL);
        BITMAP *personagem = load_bitmap("personagem.bmp", NULL);
        BITMAP *bloco = load_bitmap("bloco.bmp", NULL);
        BITMAP *inimigo = load_bitmap("inimigo.bmp", NULL);
        BITMAP *inimigo2 = load_bitmap("inimigo2.bmp", NULL);
        BITMAP *inimigo3 = load_bitmap("inimigo3.bmp", NULL);
        BITMAP *vida = load_bitmap("vida.bmp", NULL);
        BITMAP *vida1 = load_bitmap("vida1.bmp", NULL);
        BITMAP *vida2 = load_bitmap("vida2.bmp", NULL);

        bool executar = false;
        int cont = 0;

        while(!key[KEY_ESC]){
            if(pers.px == 21 && pers.py == 20){
                menu();
            }
            //Movimentos
            //movimento do arqueiro
            executar = AtaTempo(100);
            if(key[KEY_RIGHT] && mapa[pers.py][pers.px+1] != 0 && executar){
            pers.px++;
            }
            if(key[KEY_LEFT] && mapa[pers.py][pers.px-1] != 0 && executar){
            pers.px--;
            }
            if(key[KEY_DOWN] && mapa[pers.py+1][pers.px] != 0 && executar){
            pers.py++;
            }
            if(key[KEY_UP] && mapa[pers.py-1][pers.px] != 0 && executar){
            pers.py--;
            }

            // movimento inimigo
            if(executar){
                int v;
                v = (rand()%3) -1;
                if(mapa[ini.y][ini.x+v] != 0){
                    ini.x += v;
                }
                v = (rand()%3) -1;
                if(mapa[ini.y+v][ini.x] != 0){
                    ini.y += v;
                }
                v = (rand()%3) -1;
                if(mapa[ini2.y][ini2.x+v] != 0){
                    ini2.x += v;
                }
                v = (rand()%3) -1;
                if(mapa[ini2.y+v][ini2.x] != 0){
                    ini2.y += v;
                }
                 v = (rand()%3) -1;
                if(mapa[ini3.y][ini3.x+v] != 0){
                    ini3.x += v;
                } v = (rand()%3) -1;
                if(mapa[ini3.y+v][ini3.x] != 0){
                    ini3.y += v;
                }
            }


        // impressao do jogo
        masked_blit(fundo, buffer, 0,0,0,0,640,480);
        if(life.ativo == true)masked_blit(vida, buffer, 0,0,450,30,30,30);
        if(life1.ativo == true)masked_blit(vida1, buffer, 0,0,500,30,30,30);
        if(life2.ativo == true)masked_blit(vida2, buffer, 0,0,550,30,30,30);
        for(int i = 0; i < 22; i++){
            for(int j = 0; j < 22; j++){
                if(mapa[i][j] == 0){
                    masked_blit(bloco, buffer, 0, 0, j*20, i*20, 20, 20);
                }
                if(pers.py == i && pers.px == j){
                    if(pers.ativo == true)masked_blit(personagem, buffer, 0, 0, j*20, i*20, 20, 20);
                }
                if(ini.y == i && ini.x == j){
                    if(ini.ativo == true)masked_blit(inimigo, buffer, 0, 0, j*20, i*20, 20, 20);
                }
                if(ini2.y == i && ini2.x == j){
                    if(ini2.ativo == true)masked_blit(inimigo2, buffer, 0, 0, j*20, i*20, 20, 20);
                }
                if(ini3.y == i && ini3.x == j){
                    if(ini3.ativo == true)masked_blit(inimigo3, buffer, 0, 0, j*20, i*20, 20, 20);
                }
            }
        }

        //colisao com inimigo 1
        masked_blit(buffer,screen,0,0,0,0,640,480);
        if(pers.px == ini.x && pers.py == ini.y && cont == 0){
            life.ativo = false;
            cont++;
            pers.px = 1;
            pers.py = 1;
        }
        if(pers.px == ini.x && pers.py == ini.y && cont == 1){
            life1.ativo = false;
            cont++;
            pers.px = 1;
            pers.py = 1;
        }
        if(pers.px == ini.x && pers.py == ini.y && cont == 2){
            life2.ativo = false;
            cont++;
            pers.px = 1;
            pers.py = 1;
        }
        if(cont == 3){
            cont = 0;
            life.ativo = true;
            life1.ativo = true;
            life2.ativo = true;
            clear(buffer);
            menu();
        }

        //colisao com inimigo 2
        if(pers.px == ini2.x && pers.py == ini2.y && cont == 0){
            life.ativo = false;
            cont++;
            pers.px = 1;
            pers.py = 1;
        }
        if(pers.px == ini2.x && pers.py == ini2.y && cont == 1){
            life1.ativo = false;
            cont++;
            pers.px = 1;
            pers.py = 1;
        }
        if(pers.px == ini2.x && pers.py == ini2.y && cont == 2){
            life2.ativo = false;
            cont++;
            pers.px = 1;
            pers.py = 1;
        }
        if(cont == 3){
            cont = 0;
            life.ativo = true;
            life1.ativo = true;
            life2.ativo = true;
            clear(buffer);
            menu();
        }

        //colisao com inimigo 3
        if(pers.px == ini3.x && pers.py == ini3.y && cont == 0){
            life.ativo = false;
            cont++;
            pers.px = 1;
            pers.py = 1;
        }
        if(pers.px == ini3.x && pers.py == ini3.y && cont == 1){
            life1.ativo = false;
            cont++;
            pers.px = 1;
            pers.py = 1;
        }
        if(pers.px == ini3.x && pers.py == ini3.y && cont == 2){
            life2.ativo = false;
            cont++;
            pers.px = 1;
            pers.py = 1;
        }
        if(cont == 3){
            cont = 0;
            life.ativo = true;
            life1.ativo = true;
            life2.ativo = true;
            clear(buffer);
            menu();
        }
    }
}


void creditos(){
    BITMAP *buffer = create_bitmap(640,480);
    BITMAP *fundo3 = load_bitmap("fundo2.bmp", NULL);

    while(!key[KEY_ESC]){
        blit(fundo3, buffer, 0,0,0,0,640,480);
        masked_blit(buffer, screen, 0,0,0,0,640,480);
        }
    }


void init() {
    int depth, res;
    allegro_init();
    depth = desktop_color_depth();
    if (depth == 0)
        depth = 32;
    set_color_depth(depth);
    res = set_gfx_mode(GFX_AUTODETECT_WINDOWED, 640, 480, 0, 0);
    if (res != 0) {
        allegro_message(allegro_error);
        exit(-1);
}
install_timer();
install_keyboard();
install_mouse();
/* add other initializations here */
}

void deinit() {
    clear_keybuf();
/*    destroy_bitmap(buffer);
    destroy_bitmap(personagem);
    destroy_bitmap(fundo);*/
    /* add other deinitializations here */
    }
